# 1790-introduccion-a-sql-con-mysql

Este repositorio contiene los archivos referentes al curso de introducción a SQL utilizando MySQL de Alura en español.

Te invito a instalar workbench siguiendo los pasos indicados en el video 1.4.

¡Éxitos!
