const nombreMadre = "María";
const NombreMadre = "Teresa";

console.log(nombreMadre);
console.log(NombreMadre);

const nombreDeMiMadreCuandoSoltera = "María Perez";
const nombreDeMiPais = "Venezuela";
console.log(nombreDeMiMadreCuandoSoltera);
console.log(NombreMaria);

const edadMadre = 60;
const pi = 3.1416;
const esSoltero = false;
let miEdad = 40;


