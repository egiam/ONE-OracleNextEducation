console.log('Operaciones aritmeticas');
const variableTexto = "variableTexto";
console.log(variableTexto);

let nuevaVariableTexto = "Valor que cambia";
console.log(nuevaVariableTexto);

nuevaVariableTexto = "Por otro valor";
console.log(nuevaVariableTexto);

var variableGlobal = "Varible de todo el programa";
console.log(variableGlobal);

variableGlobal = "Otro valor global";
console.log(variableGlobal);

const unNumero = 10;
const numeroDecimal = 20.5;

let sumaNumeros = 0;

sumaNumeros = 2 + 2;
console.log(sumaNumeros);
sumaNumeros = 2 + 10 * 5;
console.log(sumaNumeros);
sumaNumeros = (2 + 10) * 5;
console.log(sumaNumeros);

const nombreMadre = "María";
console.log('El nombre de mi madre es:'+nombreMadre);