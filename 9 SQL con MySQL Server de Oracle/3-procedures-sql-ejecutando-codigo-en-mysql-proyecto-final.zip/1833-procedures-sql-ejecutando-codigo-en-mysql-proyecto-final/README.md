# 1833-procedures-sql-ejecutando-codigo-en-mysql

Este repositorio contiene los comandos sql utilizados en el desarrollo del curso Procedures SQL: Ejecutando código en MySQL.
