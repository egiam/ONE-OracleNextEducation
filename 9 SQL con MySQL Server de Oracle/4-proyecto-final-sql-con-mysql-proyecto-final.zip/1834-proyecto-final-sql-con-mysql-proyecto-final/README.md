# 1834-proyecto-final-sql-con-mysql
Este repositorio contiene el proyecto final de SQL con MySQL de Alura en español.
