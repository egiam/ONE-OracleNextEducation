# 1827-consultas-sql-avanzando-en-sql-con-my-sql
Este repositorio contiene los archivos de sql referentes al curso de Consultas SQL: Avanzando en SQL con MySQL
