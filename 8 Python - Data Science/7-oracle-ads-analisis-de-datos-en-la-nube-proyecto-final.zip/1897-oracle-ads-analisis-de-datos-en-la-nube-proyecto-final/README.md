# 1897-oracle-ads-analisis-de-datos-en-la-nube
En este repositorio se encuentra el notebook referente al curso de análisis de datos en la nube con Oracle ADS
