# 1918-machine-learning-clasificacion-con-sklearn
En este repositorio encontrarás el notebook y los archivos correspondientes al curso **Machine Learning: Clasificación con SKLearn** de Alura Latam.
