# Machine Learning con Oracle ADS

En este repositorio encontrarás el notebook referente al curso de **Machine Learning con Oracle ADS: Productividad en la creación de modelos** para la plataforma Alura Latam.
